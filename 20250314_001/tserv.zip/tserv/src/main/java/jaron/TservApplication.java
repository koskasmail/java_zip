package jaron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TservApplication {

	public static void main(String[] args) {
		SpringApplication.run(TservApplication.class, args);
	}

}
