package com.warehouse.inventory.WarehouseInventoryApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseInventoryApplication.class, args);
	}

}
