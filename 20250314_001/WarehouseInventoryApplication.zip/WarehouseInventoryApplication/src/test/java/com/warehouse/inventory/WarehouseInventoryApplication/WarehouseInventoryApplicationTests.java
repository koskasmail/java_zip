package com.warehouse.inventory.WarehouseInventoryApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
